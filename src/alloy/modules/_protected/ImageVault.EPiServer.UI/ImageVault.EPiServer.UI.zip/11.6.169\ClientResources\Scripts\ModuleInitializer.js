﻿define([
// Dojo
    "dojo",
    "dojo/_base/declare",
    "dojo/dnd/Manager",
    "dojo/dnd/Avatar",
//CMS
    "epi/_Module",
    "epi/dependency",
    "epi/routes",
//imagevault
    "imagevault/dnd/Avatar"
], function (
// Dojo
    dojo,
    declare,
    dndManager,
    EpiAvatar,
//CMS
    _Module,
    dependency,
    routes,
//ImageVault
    ImageVaultAvatar
) {

    return declare([_Module], {
        // summary: Module initializer for the default module.

        initialize: function () {

            this.inherited(arguments);

            var registry = this.resolveDependency("epi.storeregistry");

            //Register the store
            registry.create("imagevault.browserstore", this._getRestPath("imagevaultbrowserstore"));
            registry.create("imagevault.mediaitemstore", this._getRestPath("imagevaultmediaitemstore"));
            registry.create("imagevault.propertymediacommonsettingsstore", this._getRestPath("imagevaultpropertymediacommonsettingsstore"));
            registry.create("imagevault.categorystore", this._getRestPath("imagevaultcategorystore"));
            registry.create("imagevault.mediapropertydatastore", this._getRestPath("imagevaultmediapropertydatastore"));
            registry.create("imagevault.medialistpropertydatastore", this._getRestPath("imagevaultmedialistpropertydatastore"));

            //HACK, the avatar class is just a copy of EPiServers Avatar but with the posibility to fully customize the avatar creation.
            // DnD manager customizations (overrides the customizations made in epi/shell/ShellModule)
            var manager = dndManager.manager();
            manager.makeAvatar = function () {
                if (this.source.accept.hasOwnProperty('ImageVaultMedia')) {
                    return new ImageVaultAvatar(this);
                }
                return new EpiAvatar(this);
            };
        },

        _getRestPath: function (name) {
            return routes.getRestPath({ moduleArea: "ImageVault.EPiServer.UI", storeName: name });
        }
    });
});