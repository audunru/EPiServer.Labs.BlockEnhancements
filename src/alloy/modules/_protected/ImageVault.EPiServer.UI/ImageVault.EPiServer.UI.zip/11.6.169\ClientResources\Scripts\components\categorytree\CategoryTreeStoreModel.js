define("imagevault/components/categorytree/CategoryTreeStoreModel", [
    "dojo",
    "dojo/_base/declare",
    "epi/dependency"//,
//    "dojo/_base/xhr",
  //  "epi/routes"
], function (dojo, declare, dependency) {

    // module:
    //      epi-cms/widget/CategoryTreeStoreModel

    return declare(null, {
        // summary:
        //      store model for category tree.

        // store: [protected] dojo.store.api.Store
        //      Underlying store that will be queried for category tree items.
        store: null,

        // rootCategory: [protected]
        //      Store root category id.
        rootCategory: undefined,

        constructor: function (args) {

            dojo.mixin(this, args);

            if (!this.store) {
                var registry = dependency.resolve("epi.storeregistry");
                this.store = registry.get("imagevault.categorystore");
                this.store.idProperty = "Id";
            }

        },

        getCategories: function () {
            // summary:
            //      Loads all categories. We read all categories at the same time from the store 
            return this.store.query();
        },
        
        // =======================================================================
        // Methods for traversing hierarchy

        getRoot: function (onItem) {
            // summary:
            //      Calls onItem with the root item for the tree, possibly a fabricated item.

            dojo.when(this.getCategories().then(function (arr) {
                return { Id: "root", Name: "Categories", Categories: arr };
            }), onItem);
        },

        mayHaveChildren: function (item) {
            // summary:
            //      Tells if an item has or may have children.  Implementing logic here
            //      avoids showing +/- expando icon for nodes that we know don't have children.
            //      (For efficiency reasons we may not want to check if an element actually
            //      has children until user clicks the expando node)

            return item.Categories && item.Categories.length;
        },

        getChildren: function (parentItem, onComplete) {
            // summary:
            //      Calls onComplete() with array of child items of given parent item, all loaded.
            onComplete(parentItem.Categories);
        },

        // =======================================================================
        // Inspecting items

        getIdentity: function (item) {
            // summary:
            //      Returns identity for an item

            return this.store.getIdentity(item);
        },

        getLabel: function (item) {
            // summary:
            //      Get the label for an item

            return item.Name;
        }
    });
});