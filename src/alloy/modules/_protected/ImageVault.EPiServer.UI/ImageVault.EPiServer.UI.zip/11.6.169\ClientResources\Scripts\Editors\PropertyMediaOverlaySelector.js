﻿define([
// Dojo
	"dojo/_base/declare",
	"dojo/_base/array",
    "dojo/html",
    "dojo/dom-attr",
    "dojo/dom-style",
    "dojo/dom-class",
    "dojo/dom",
    "dojo/_base/event",
    "dojo/keys",
    "dojo/_base/lang",
    "dojo/on",
    "dojo/dom-construct",
    "dojo/window",
    "dojo/dom-geometry",
    "dojo/query",
    "dojo/has",
    "dojo/_base/Deferred",

// Dijit
    "dijit/_CssStateMixin",
    "dijit/_WidgetsInTemplateMixin",
    "dijit/place",
    "dijit/_Container",
    "dijit/form/DropDownButton",

// epi
    "epi/epi",
	"epi/shell/widget/overlay/Item",
    "epi/dependency",
    "epi/shell/dnd/Target",
    "epi-cms/_ContentContextMixin",

// imagevault
    "imagevault/contentediting/ImageVaultContextMenu",
    "imagevault/contentediting/_ImageVaultContextMenuModelMixin",
    "imagevault/_ErrorDisplayMixin",
    "imagevault/_PropertyMediaMixin",
    "epi/i18n!epi/shell/ui/nls/imagevault.imagevaultoverlay",
    "imagevault/RequireModule!ImageVault.EPiServer.UI"
],
function (
// Dojo
    declare,
    array,
    html,
    domAttr,
    domStyle,
    domClass,
    dom,
    event,
    keys,
    lang,
    on,
    domConstruct,
    win,
    domGeom,
    query,
    has,
    Deferred,

// Dijit
    _CssStateMixin,
    _WidgetsInTemplateMixin,
    place,
    _Container,
    DropDownButton,

// epi
    epi,
    Item,
    dependency,
    Target,
    _ContentContextMixin,

//imagevault
    ImageVaultContextMenu,
    _ImageVaultContextMenuModelMixin,
    _ErrorDisplayMixin,
    _PropertyMediaMixin,
    res,
    appModule
) {
    return declare([Item, _WidgetsInTemplateMixin, _CssStateMixin, _PropertyMediaMixin, _Container, _ImageVaultContextMenuModelMixin, _ContentContextMixin, _ErrorDisplayMixin], {
        //ondijitclick is the preferred onclick event
        //informationNode added in 7.5 (border and info tab around property)
        templateString: '<div data-dojo-attach-point="item" class="epi-overlay-item">\
                          <div data-dojo-attach-point="containerNode" data-dojo-attach-event="mouseenter:_mouseOver,mouseleave:_mouseOut,ondijitclick:_onClick" class="epi-overlay-item-container">\
                          <div data-dojo-attach-event="mouseleave:_mouseLeaveBehindMenu">\
                          <button data-dojo-attach-point="settingsButton" data-dojo-type="dijit/form/DropDownButton" data-dojo-props="showLabel:false, title:&quot;${resources.settingstooltip}&quot;, iconClass:&quot;epi-iconContextMenu&quot;, class:&quot;epi-chromelessButton epi-overlayControls epi-settingsButton epi-mediumButton&quot;"><div data-dojo-attach-point="contextMenu" data-dojo-type="imagevault/contentediting/ImageVaultContextMenu"></div></button>\
                          </div>\
                          <div class="epi-overlay-bracket"></div>\
                          </div>\
                          <div data-dojo-attach-point="ivNode" class="ivNode" style="visibility:hidden"> <iframe src="" style="width: 1500px; height: 600px; border: none; overflow: hidden;"></iframe>\
                          </div>\
                          <span data-dojo-attach-point="informationNode" class="epi-overlay-item-info" />\
                          </div>\
                         ',
        baseClass: "ivpmo",
        value: null,
        // property settings
        width: null,
        height: null,
        resizeMode: null,
        thumbFormatId: null,
        // values for Crop/Zoom try to get this from Store
        mediaReference: null,
        thumbCache: { Thumb: { Url: "" } },
        dropTargetType: ["ImageVaultMedia"],

        resources: res,
        fullName: null,

        constructor: function (/*parameters*/) {
            this._handlers = [];

            // HACK: Since this editor wrapper doesn't have an editor widget, mix the editorParams into this.
            //            lang.mixin(this, parameters.editorParams);
            //            delete parameters.editorParams;
        },

        _mouseOverIE: function (e) {
            e = $.event.fix(e);
            // bugg fix for IE
            domClass.remove(this.item, "dojoDndContainerOver");
            e.stopPropagation();
            e.cancelBubble = true;
        },

        _mouseOver: function () {
            // check if we have a mediaReference.
            if (!this.mediaReference)
                return;

            var mediaCache = JSON.parse(this.thumbCache);
            var pmc = new ImageVault.PropertyMediaCommon();
            pmc.targetWidth = this.width;
            pmc.targetHeight = this.height;

            // create popup.
            if ((!this._isVideo(mediaCache) && this.width && this.width > mediaCache.Original.Width) || (!this._isVideo(mediaCache) && this.height && this.height > mediaCache.Original.Height) || !pmc.isEditable(mediaCache))
                domConstruct.place("<div id='ivNotEditable'>" + pmc.getEditableStatusMessage(mediaCache) + "</div>", this.containerNode);

            return;
        },
        _mouseOut: function () {
            // remove popup.
            domConstruct.destroy(dom.byId("ivNotEditable"));
            return false;
        },

        _mouseLeaveBehindMenu: function (e) {
            if (domClass.contains(e.fromElement, "epi-iconContextMenu")) {
                // if we arrive here from the context menu,
                // stop the event to avoid menu blur
                event.stop(e);
            }
        },

        onBlur: function () {
            this.inherited(arguments);
        },

        _onClick: function (e) {
            e = $.event.fix(e);

            var widget = dijit.getEnclosingWidget(e.originalTarget || e.target);

            event.stop(e);

            if (widget && widget.isInstanceOf(DropDownButton)) {
                return;
            }

            this.ShowCropZoom(this);
        },

        _isVideo: function (mediaCache) {
            return mediaCache && mediaCache.OriginalFormatContentType && mediaCache.OriginalFormatContentType.indexOf("video/") === 0;
        },

        ShowCropZoom: function (self) {

            if (!self.mediaReference)
                return;

            if (domStyle.get(self.ivNode, "visibility") == "visible")
                return;

            // if the image is smaller then property with and height you can't use crop/zoom.
            var mediaCache = JSON.parse(self.thumbCache);
            if ((!self._isVideo(mediaCache) && self.width && self.width > mediaCache.Original.Width) || (!self._isVideo(mediaCache) && self.height && self.height > mediaCache.Original.Height))
                return;

            var pmc = new ImageVault.PropertyMediaCommon();
            if (!pmc.isEditable(mediaCache))
                return;

            // disable all other editable properties while editor is open
            query(".epi-overlay-item, .epi-overlay-item-container, .epi-overlay-blockarea-container, .epi-overlay-blockarea-actionscontainer").style("visibility", "hidden");

            // Fix for IE, if we don't make this visible IE can't set ivNode visible.
            domStyle.set(self.item, "visibility", "visible");
            // show ivNode that contains Crop/Zoom editor, hide contanerNode
            domStyle.set(self.ivNode, "visibility", "visible");

            // get top menu offset
            var menuOffset = domGeom.position(query(".epi-editorViewport")[0]).y;

            // get navigation pane offset
            var navPane = query("#navigation")[0];
            var navPanePos = domGeom.position(navPane);

            // scroll into view
            // if image height is greater than the editor viewport, we use the viewport as height instead.
            var pos = domGeom.position(this.containerNode);
            var fakeHeight = $(".epi-editorViewport-previewBox").height();

            // bug fix for IE, IE adds 4 extra pixlars and we need to remove them.
            var yPosition = pos.y;
            if (has("ie")) {
                fakeHeight -= 4;
                if (yPosition >= 90)
                    yPosition += 4;
            }
            win.scrollIntoView(this.containerNode, { w: pos.w, h: pos.h > fakeHeight ? fakeHeight : pos.h + 100, x: pos.x, y: yPosition });    // need to append the extra height 100 px to the image in order to scroll it above editor action bar

            // initialize Crop/Zoom editor
            var nodeCoords = domGeom.position(self.containerNode);
            nodeCoords.menuOffset = menuOffset;
            nodeCoords.containerBorderWidth = 4;
            nodeCoords.navPaneWidth = navPanePos.w;
            nodeCoords.contentWidth = $(".epi-editorViewport-previewBox .dijitReset").width();

            self.editorInstance(self);

            // Set size of iframe
            var editorWidth = $(".epi-editorViewport-previewBox").width() || $(document).width();
            var editorHeight = $(".epi-editorViewport-previewBox").height() || $(document).height() - nodeCoords.menuOffset;

            var $iframe = $("iframe",self.ivNode);
            $iframe.css("width", editorWidth);
            $iframe.css("height", editorHeight);

            // Place iv node
            domStyle.set(self.ivNode, {
                position: "absolute",
                left: -(nodeCoords.x) - self.containerNode.clientLeft + navPanePos.w + "px",
                top: -(nodeCoords.y) - self.containerNode.clientTop + menuOffset + "px"
            });


            self.nodeCoords = nodeCoords;

            // bug fix for IE, ContextMenu visible in editor.
            domClass.remove(this.item, "dojoDndContainerOver");

        },

        _setupDnd: function () {
            //setup droparea and type
            if (this.dropTargetType) {
                this._dropTarget = new Target(this.domNode, {
                    accept: [this.dropTargetType],
                    createItemOnDrop: false
                });

                this.connect(this._dropTarget, "onDropData", "_onDropData");
            }
        },

        buildRendering: function () {
            this.inherited(arguments);
        },

        postCreate: function () {

            this.inherited(arguments);

            this.ErrorNode = this.ivNode;

            //select node that should be droppable (_DroppableMixin).
            this._setupDnd();

            //setup contextmenu for delete image.
            this._setupContextMenu();

            // subscribe to videoeditor is closing
            this.subscribe("/imagevault/propertymediacommon/editorclosed", this.resetEditor);

            try {
                //setup the stores
                if (!this.store || !this.datastore) {
                    var registry = dependency.resolve("epi.storeregistry");
                    this.store = registry.get("imagevault.mediaitemstore");
                    this.datastore = registry.get("imagevault.mediapropertydatastore");
                }
            } catch (err) {
                this.ShowError("Error initializing store: " + err);
            }

            //load all needed scripts using the _PropertyMediaMixin
            this.loadScripts().then(lang.hitch(this, function () {

                // then load the property data
                Deferred.when(this.datastore.query({ contextId: this.getCurrentContext().id, propertyName: this.fullName, mode: this.getCurrentContext().currentMode }), lang.hitch(this, function (storeResponse) {
                    if (storeResponse.ErrorCode) {
                        // something went wrong
                        this.ShowError("Error in store:" + storeResponse.ErrorMessage);
                        return;
                    }
                    // set all properties
                    this.thumbFormatId = storeResponse.ThumbFormatId;
                    this.thumbCache = storeResponse.ThumbCache;
                    this.mediaReference = storeResponse.MediaReference;
                    this.width = storeResponse.PropertySettings.Width;
                    this.height = storeResponse.PropertySettings.Height;
                    this.resizeMode = storeResponse.PropertySettings.ResizeMode;
                    // show empty placeholder if we do not have any value
                    if (!this.mediaReference) {
                        domClass.add(this.item, "ivEmptyValue");
                    }

                    //init the auth util 
                    this._authUtil = new ImageVault.AuthUtil();
                }));

            }));
        },

        remove: function () {
            domClass.add(this.item, "ivEmptyValue");
            this._setValue(null, this);
        },

        _setupContextMenu: function () {
            // summary:
            //      Setup block context menu
            // tag:
            //      Private

            if (this.settingsButton.dropDownPosition) {
                this.settingsButton.dropDownPosition = ["below", "above"];
            }

            // if dropDown object not automatically set on DropDownButton widget, set it manually
            if (!this.settingsButton.dropDown) {
                this.settingsButton.dropDown = this.contextMenu;
            }

            this.connect(this.contextMenu, "onOpen", "_onContextMenuOpen");
        },

        _onContextMenuOpen: function () {
            //selectedItem is defined in the ImageVaultContextMenuModelMixin class and is needed for the BlockRemove class to work
            this.selectedItem = this.mediaReference;
            this.contextMenu.set("model", this);
        },

        resetEditor: function (self) {
            if (!self)
                self = this;
            // hide and clear editor window, show containerNode
            domStyle.set(self.ivNode, "visibility", "hidden");

            // enable all editable properties again
            query(".epi-overlay-item, .epi-overlay-item-container, .epi-overlay-blockarea-container, .epi-overlay-blockarea-actionscontainer").forEach(function (node) {
                domStyle.set(node, "visibility", "visible");
            });
        },

        editorInstance: function (self) {
            if (self.thumbCache) {

                var mediaCache = JSON.parse(self.thumbCache);
                var mediaRef = JSON.parse(self.mediaReference);

                var isVideo = self._isVideo(mediaCache);

                if (ImageVault.ClientInstance == undefined)
                    ImageVault.ClientInstance = new ImageVault.Client({
                        core: ImageVault.PropertyMediaCommon.ivCoreProxy,
                        authMethod: "none"
                    });

                self._authUtil.checkLoginStatus(null,
					function (status) {
					    if (!status)
					        alert("Cannot edit media, need to be logged into ImageVault first");

					    // Using a "dummy" PropertyMediaCommon here for now, to open
					    // the video editor in fancybox. This PMC is not initialized with all values.
					    var pmc = new ImageVault.PropertyMediaCommon();
					    if (isVideo) {
					        // handle callback from clicking OK in fancybox
					        pmc.storeEffects = function (effects, callbackParams) {

					            // if we have a value we will save it
					            if (effects) {
					                mediaRef.Effects = effects;
					                self._setValue(mediaRef, self);
					            }

					            // reset editor
					            self.resetEditor(self);

					            setTimeout(function () {
					                // Try again
					                self._setValue(mediaRef, self);
					                self.resetEditor();
					            },
					                2000);
					        };

					        // open the editor
					        pmc.openEditor(mediaCache, mediaRef, null, null, false, self, isVideo);
					    } else {
					        pmc.openEditor(mediaCache, mediaRef, null, null, true, self, isVideo,null, $("iframe",self.ivNode));
					    }
					});
            }
        },

        _onDropData: function (dndData/*, source, nodes, copy*/) {
            //get droped item
            if (dndData.length > 1) {
                this.onDrop(this, dndData);
            } else if (dndData.length === 1) {
                this.onDrop(this, dndData[0]);
            }
        },

        onDrop: function (self, dropItem) {
            dojo.when(self.store.query({ id: dropItem.data.Id, formatId: self.thumbFormatId }), function (mediaCache) {

                //create mediaReference and store the value
                var mediaReference = {
                    Id: dropItem.data.Id,
                    Effects: [
                    {
                        "$type": "ImageVault.Common.Data.Effects.ResizeEffect, ImageVault.Common",
                        "Width": self.width,
                        "Height": self.height,
                        "ResizeMode": self.resizeMode
                    }
                    ]
                };

                //update thumbCache
                self.thumbCache = JSON.stringify(mediaCache);

                //update image
                self._setValue(mediaReference, self);


                domClass.remove(self.item, "ivEmptyValue");

                // remove and trigger not editable popup if needed. 
                self._mouseOut();
                self._mouseOver();
            });
        },

        _setValue: function (value, self) {
            if (value === null || typeof (value) === "undefined" || value === "") {
                self.onValueChange({ propertyName: self.name, value: null });
                self.mediaReference = null;
            }

            if (value && (value.id || value.Id)) {
                //saves the new value, it will then reload the image
                self.onValueChange({ propertyName: self.name, value: value });

                //reset mediaReference, take this away when we use store to get mediaReference
                self.mediaReference = JSON.stringify(value);
            }
        },

        // this function is needed for onValueChange to get triggered in _setValue
        onValueChange: function () { }
    });
});