﻿(function ($, ns) {

    var pml = function (config) {
        config.uri = ImageVault.PropertyMediaCommon.uri;
        config.clearConfirmMessage = ImageVault.PropertyMediaCommon.clearConfirmMessage;
        config.defaultIconUri = ImageVault.PropertyMediaCommon.defaultIconUri;
        this.init(config);
        return this;
    };

    //inherit from PropertyMediaCommon
    $.extend(pml.prototype, ImageVault.PropertyMediaCommon.prototype);

    //add class specific get
    $.extend(pml.prototype, {
        //properties
        mediaListId: null,
        defaultThumbnailId: null,
        editLinkId: null,
        inserLinkId: null,
        targetWidth: 0,
        targetHeight: 0,
        resizeMode: 0, //0 ScaleToFit, 1 ScaleToFill
        originalContentType: null,
        originalWidth: null,
        originalHeight: null,
        $mediaList: null,
        _movedIndex: -1,
        _tabEventsHooked: false,
        //methods
        init: function (config) {
            $.extend(this, config);
            var self = this;
            this.$editLink = $("#" + this.editLinkId);

            //click on the thumbnail itself
            $("#" + this.defaultThumbnailId).parent().click(function () {
                self.OpenImageVault(true);
            });
            //click on the insert button
            $("#" + this.inserLinkId).click(function () {
                self.OpenImageVault(true);
            });
            //click on the remove button
            $("#" + this.removeLinkId).click(function () {
                self.ClearSelection();
            });
            this.$mediaList = $('#' + this.mediaListId);
            if (this.readOnly) {
                $('.propertymedialist-thumbnail-container', this.$mediaList).addClass("disabled");
            }
            //wire hover event for all thumbs
            $('li', this.$mediaList).hover(function () { self.mouseOverThumb(this); }, function () { self.mouseOutThumb(this); });
            $('.propertymedialist-item-remove', this.$mediaList).live('click', function () {
                try {
                    var index = $('.propertymedialist-item-remove', self.$mediaList).index(this);
                    var itemToRemove = $(this).closest('li');
                    self.removeMediaItem(index, itemToRemove);
                } catch (e) {
                    alert(e.message);
                }
                return false;
            });
            $('.propertymedialist-item-edit', this.$mediaList).live('click', function () {
                try {
                    if ($("i", $(this)).hasClass("propertymedialist-icon-edit-disabled"))
                        return false;
                    var index = $('.media-list-item', self.$mediaList).index($(this).parent());
                    var item = $(this).closest('li');
                    self.editItem(index, item);
                } catch (e) {
                    alert(e.message);
                }
                return false;
            });

            $(".propertymedialist-item-edit")
                .bind("mouseenter", function () { self.mouseOverEditButton(this); })
                .bind("mouseleave", function () { self.mouseOutEditButton(this); });

            if (!this.readOnly) {
                //add sortable for the list
                this.$mediaList.sortable({
                    items: "li:not(.ui-state-disabled)",
                    helper: 'clone',
                    start: function (e, u) {
                        var index = self.indexOfElement(u.item[0], e.target.children);
                        self._movedIndex = index;
                    },
                    stop: function (e, u) {
                        var index = self.indexOfElement(u.item[0], e.target.children);
                        if (self._movedIndex < 0) {
                            alert("Error in moving item. No start position set. Reload page and try again.");
                            return;
                        }
                        //moved to itself. Ignore
                        if (self._movedIndex == index) {
                            self._movedIndex = -1;
                            return;
                        }
                        // update the ids and thumbnailcache with the correct order
                        var mediaCacheList = self.getMediaCacheList();
                        var mediaReferenceList = self.getMediaReferenceList();
                        self.moveItem(mediaCacheList, self._movedIndex, index);
                        self.moveItem(mediaReferenceList, self._movedIndex, index);
                        self.setMediaCacheList(mediaCacheList);
                        self.setMediaReferenceList(mediaReferenceList);

                        //reset index
                        self._movedIndex = -1;
                    }
                });
            }
            //load event is triggered if image isn't loaded when script executes
            this.$mediaList.find(".propertymedialist-thumbnail").load(function () {
                self.centerThumbnail($(this), null, true);
            });
            //manually trigger the centerThumbnail for all images that already are loaded
            this.$mediaList.find(".propertymedialist-thumbnail").each(function () {
                self.centerThumbnail($(this), null, true);
            });

            //Hook up an eventhandler for computing the media position, based on size, to each page-setting-tab.
            if (!this._tabEventsHooked) {
                $(".epi-tinyTabs .epi-tabView-tab").live("click", function () {
                    self.$mediaList.find(".propertymedialist-thumbnail").each(function () {
                        self.centerThumbnail($(this), null, true);
                    });
                });
                this._tabEventsHooked = true;
            }

            //Kontrollera att sparad media är valid.
            var items = this.getMediaReferenceList();
            this.validateMedia(items);

            this.UpdateUi();
        },
        //moves an item in an array from one position to another
        moveItem: function (items, fromIndex, toIndex) {
            if (fromIndex == toIndex) return;
            var itemToMove = items[fromIndex];
            items.splice(fromIndex, 1);
            items.splice(toIndex, 0, itemToMove);
        },
        //finds the index of the supplied element in the list of nodes
        indexOfElement: function (node, nodes) {
            if (!nodes || !nodes.length || !node) return -1;
            for (var i = 0; i < nodes.length; i++) {
                if (nodes[i] == node) return i;
            }
            return -1;
        },
        mouseOverEditButton: function (elem) {
            var $elem = $(elem);
            //ignore non disabled buttons
            if (!$("i", $elem).hasClass("propertymedialist-icon-edit-disabled"))
                return true;

            if ($(".propertymedia-message-popup", $elem).length > 0) {
                $(".propertymedia-message-popup", $elem).css("visibility", "");
                return true;
            }

            var index = $('.media-list-item', this.$mediaList).index($elem.parent());
            //get mediaCache info
            var mediaCacheItems = this.getMediaCacheList();
            var mediaCache = mediaCacheItems[index];

            var $popup = this.createMessagePopup($elem, mediaCache);
            $popup.css("left", "-12px").css("bottom", "35px");
            return true;
        },
        mouseOutEditButton: function (elem) {
            $(".propertymedia-message-popup", $(elem)).css("visibility", "hidden");
        },
        mouseOverThumb: function (li) {
            if (this.readOnly)
                return;

            $(li).find('.propertymedialist-item-remove').css("visibility", "visible");
            $(li).find('.propertymedialist-item-edit').css("visibility", "visible");
        },
        mouseOutThumb: function (li) {
            $(li).find('.propertymedialist-item-remove').css("visibility", "hidden");
            $(li).find('.propertymedialist-item-edit').css("visibility", "hidden");
        },
        removeMediaItem: function (index, itemToRemove) {
            if (this.readOnly)
                return;

            try {
                var mediaReferenceList = this.getMediaReferenceList();
                var mediaCacheItems = this.getMediaCacheList();
                mediaReferenceList.splice(index, 1);
                mediaCacheItems.splice(index, 1);
                this.setMediaReferenceList(mediaReferenceList);
                this.setMediaCacheList(mediaCacheItems);
                $(itemToRemove).remove();
            }
            catch (e) {
                console.log('An error has occurred: ' + e.message);
            }
        },
        editItem: function (index, $liItem) {
            if (this.readOnly)
                return;

            $.event.trigger('/imagevault/propertymedialiststartedit', this);

            var mediaCacheItems = this.getMediaCacheList();
            var mediaCache = mediaCacheItems[index];
            var mediaRefereceList = this.getMediaReferenceList();
            var mediaReference = mediaRefereceList[index];
            this.openEditor(mediaCache, mediaReference, index);
        },
        //callback for updating effects in selected media
        storeEffects: function (effects, index) {
            var self = this;
            var $listItem = $($('li', self.$mediaList)[index]);
            var $listItemImage = $listItem.find('img');
            self.showLoader($listItemImage);

			$listItemImage.attr("src", "")
			
            var mediaReferenceList = this.getMediaReferenceList();
            var mediaReference = mediaReferenceList[index];

            mediaReference.Effects = effects;
            mediaReferenceList[index] = mediaReference;
            this.setMediaReferenceList(mediaReferenceList);

            var mediaCacheItems = self.getMediaCacheList();
            var mediaCache = mediaCacheItems[index];
            this.getMedia(mediaReference, mediaCache.OriginalFormatContentType, this.propertyThumbnailWidth, this.propertyThumbnailHeight, this.propertyThumbnailResizeMode, function (mediaItem) {

                if (mediaItem) {

                    mediaCache.Thumb = mediaItem.MediaConversions[0];

                    $listItemImage.attr("src", mediaCache.Thumb.Url)
                        .attr("width", mediaCache.Thumb.Width)
                        .attr("height", mediaCache.Thumb.Height)
                        .load(function() { self.centerThumbnail($(this), null, true); });
                    mediaCacheItems[index] = mediaCache;
                    self.setMediaCacheList(mediaCacheItems);
                } else {
                    // Hide loader
                    self.hideLoader($listItemImage);
                }
            });

        },
        getMediaCacheList: function () {
            var $thumbnailHiddenField = $('#' + this.thumbnailHiddenFieldId);
            var val = $thumbnailHiddenField.val();
            return this._parseJsonArray(val);
        },
        //updates the mediaCacheList to the control, 
        //mediaCahceList: a json object or string representing the mediaCache list to store
        setMediaCacheList: function (mediaCacheList) {
            var $thumbnailHiddenField = $('#' + this.thumbnailHiddenFieldId);
            if (typeof mediaCacheList === "object")
                mediaCacheList = JSON.stringify(mediaCacheList);
            $thumbnailHiddenField.val(mediaCacheList);
        },
        getMediaReferenceList: function () {
            var val = this.getHiddenFieldValue();
            return this._parseJsonArray(val);
        },
        // Also looks one level down on the object and JSON-ifies that level as well, if they are strings
        _parseJsonArray: function (val) {
            var obj = null;
            if (val) {
                obj = JSON.parse(val);
                if (obj) {
                    for (var i = 0; i < obj.length; i++) {
                        if (typeof (obj[i]) == "string") {
                            obj[i] = JSON.parse(obj[i]);
                        }
                    }
                }
            }
            if (!obj || !(obj instanceof Array))
                obj = [];
            return obj;
        },
        //updates the mediaReferenceList to the control, 
        //mediaReferenceList: a json object or string representing the mediaReference list to store
        setMediaReferenceList: function (mediaReferenceList) {
            if (typeof mediaReferenceList === "object")
                mediaReferenceList = JSON.stringify(mediaReferenceList);
            this.setHiddenFieldValue(mediaReferenceList);
            $.event.trigger("/imagevault/propertymedialist", this);
        },
        callback: function (data) {
            var self = this;
            var mediaCacheItems = this.getMediaCacheList();
            var mediaReferences = this.getMediaReferenceList();
            var insertOffset = mediaCacheItems.length;
            var itemsToInsert = data.length;
            for (var i = 0; i < data.length; i++) {
                var mediaReference = { Id: data[i].Id };
                var cache = null;
                mediaReferences.push(mediaReference);
                mediaCacheItems.push(cache);
            }
            for (var i = 0; i < data.length; i++) {
                //Append the position in the array to the dataobject
                data[i].propertyListIndex = i;
                this.createMediaCache(data[i], function (cache) {
                    //Atleast view access when selected
                    cache.VaultRole = 1;
                    mediaCacheItems[insertOffset + cache.PropertyListIndex] = cache;
                    itemsToInsert--;
                    if (itemsToInsert == 0) {
                        for (var j = 0; j < data.length; j++) {
                            var cache = mediaCacheItems[insertOffset + j];
                            self.RenderListItem(cache);

                        }

                        self.setMediaReferenceList(mediaReferences);
                        self.setMediaCacheList(mediaCacheItems);

                        $('#' + self.removeLinkId).removeClass('propertymedia-btn-disabled');

                    }
                });
            }
        },

        RenderListItem: function (data) {

            var self = this;
            var $mediaList = $('#' + this.mediaListId);

            var $listItem;
            var canRemove = !this.readOnly;

            if (data != null) {

                var url = data.Thumb.Url;
                var thumbWidth = data.Thumb.Width;
                var thumbHeight = data.Thumb.Height;
                var json = JSON.stringify(data);
                var editable = this.isEditable(data) && !this.readOnly;

                $listItem = $(
                    '<li class="media-list-item" data-mediaReference="{&quot;Id&quot;:' +
                    data.Id +
                    '}" data-cache="' +
                    this.htmlEncode(json) +
                    '" >' +
                    '<a href="" class="propertymedia-btn propertymedialist-item-edit">' +
                    '<i class="propertymedialist-icon-edit' +
                    (editable ? '' : '-disabled') +
                    '"></i>' +
                    '</a>' +
                    '<a href="" class="propertymedia-btn propertymedialist-item-remove"><i class="propertymedialist-icon-remove' +
                    (canRemove ? '' : '-disabled') +
                    '"></i></a>' +
                    '<span class="propertymedialist-thumbnail-container' +
                    (this.readOnly ? ' disabled' : '') +
                    '"><img src="' +
                    this.htmlEncode(url) +
                    '" width="' +
                    thumbWidth +
                    '" height="' +
                    thumbHeight +
                    '" alt="" /><div class="image-loader" style="display: none;"></div></span>' +
                    '</li>');


            } else {
                // Removed item or item withous acccess rights
                $listItem = $(
                    '<li class="media-list-item">' +
                    '<a href="" class="propertymedia-btn propertymedialist-item-remove"><i class="propertymedialist-icon-remove' +
                    (canRemove ? '' : '-disabled') +
                    '"></i></a>' +
                    '<span class="propertymedialist-thumbnail-container"><span class=\"no-access-to-media-text\">Cannot find media in ImageVault. It\'s either removed or you don\'t have access.</span></span>' +
                    '</li>');
            }


            $listItem.hover(function () { self.mouseOverThumb(this); }, function () { self.mouseOutThumb(this); });

            $mediaList.find('li:last-child').before($listItem);

            var $listItemImage = $listItem.find('img');

            // Add loader
            self.showLoader($listItemImage);

            $listItemImage.load(function () {
                self.centerThumbnail($(this), null, true);
                // Hide loader
                self.hideLoader($listItemImage);
            });
            $listItem.find(".propertymedialist-item-edit")
				.bind("mouseenter", function () { self.mouseOverEditButton(this); })
				.bind("mouseleave", function () { self.mouseOutEditButton(this); });
        },

        ClearSelection: function () {
            if (this.readOnly)
                return false;

            if ($('#' + this.removeLinkId).hasClass('propertymedia-btn-disabled')) {
                return false;
            }
            var doClear = confirm(this.clearConfirmMessage);
            if (doClear) {

                this.setHiddenFieldValue("");
                var thumbnailHidden = document.getElementById(this.thumbnailHiddenFieldId);
                thumbnailHidden.value = '';

                var $mediaList = $('#' + this.mediaListId);
                $('li:not(:last)', $mediaList).remove();

                $('#' + this.removeLinkId).addClass('propertymedia-btn-disabled');

                $.event.trigger("/imagevault/propertymedialist", this);
            }

            return false;
        },
        UpdateUi: function () {
            var $insertLink = $("#" + this.inserLinkId);
            if (this.readOnly) {
                $insertLink.addClass('propertymedia-btn-disabled');
            } else {
                $insertLink.removeClass('propertymedia-btn-disabled');
            }

            var $removeLink = $("#" + this.removeLinkId);
            var items = this.getMediaReferenceList();
            if (this.readOnly || items.length == 0) {
                $removeLink.addClass("propertymedia-btn-disabled");
            } else {
                $removeLink.removeClass("propertymedia-btn-disabled");
            }

        },
        // Kontrollerar att ej längre existerande bilder filtreras bort ur listan.
        validateMedia: function (items) {
            var cache = this.getMediaCacheList();
            if (cache.length < items.length) {

                //interna hjälp-funktioner
                var equals = function (a, b) {
                    return a.Id == b.Id;
                };
                var in_array = function (i, arr) {
                    return $.grep(arr, function (itm) {
                        return equals(i, itm);
                    }).length > 0;
                };

                var removeIndicies = [];
                for (var i = 0; i < items.length; i++) {
                    if (!in_array(items[i], cache)) {
                        removeIndicies.push(i);
                    }
                }
                var nbr = removeIndicies.length;
                //Pop'a och tag bort media (i rätt ordning)
                for (var i = 0; i < nbr; i++) {
                    items.splice(removeIndicies.pop(), 1);
                }
                //Uppdatera hiddenField med ny information
                this.setMediaReferenceList(JSON.stringify(items));
            }
            return items;
        }

    });
    ns.PropertyMediaList = pml;
})(iv_jQuery, window.ImageVault != null ? window.ImageVault : window.ImageVault = {});
