﻿(function ($, ns) {

    var pm = function (config) {
        config.uri = ImageVault.PropertyMediaCommon.uri;
        config.clearConfirmMessage = ImageVault.PropertyMediaCommon.clearConfirmMessage;
        config.defaultIconUri = ImageVault.PropertyMediaCommon.defaultIconUri;
        this.init(config);
        return this;
    };

    //inherit from PropertyMediaCommon
    $.extend(pm.prototype, ImageVault.PropertyMediaCommon.prototype);

    //add class specific members
    $.extend(pm.prototype, {
        //properties
        thumbnailId: null,
        editLinkId: null,
        inserLinkId: null,
        $editLink: null,
        mediaCache: null,
        clickEvents: true,
        //methods
        init: function (config) {
            $.extend(this, config);
            var self = this;
            this.$editLink = $("#" + this.editLinkId);

            if (self.clickEvents) {
                //click on the thumbnail itself
                $("#" + this.thumbnailId).parent().click(function () {
                    self.OpenImageVault(false);
                });
                //click on the insert button
                $("#" + this.inserLinkId).click(function () {
                    self.OpenImageVault(false);
                });
                //click on the remove button
                $("#" + this.removeLinkId).click(function () {
                    self.ClearSelection();
                });
                //hookup edit button
                this.$editLink.click(function () {
                    try {
                        if ($(this).hasClass("propertymedia-btn-disabled"))
                            return false;
                        self.edit();
                    } catch (err) {
                        alert(err.message);
                    }
                    return false;
                });
            }
            //read starter data from server
            var j = $("#" + this.thumbnailHiddenFieldId).val();
            if (j) {
                this.mediaCache = JSON.parse(j);
            }

            this.$editLink
                .bind("mouseenter", function () { self.mouseOverEditButton(this); })
                .bind("mouseleave", function () { self.mouseOutEditButton(this); });

            this.UpdateUi();

            //manually call centerThumbnail if image already is loaded
            this.centerThumbnail($("#" + self.thumbnailId), self.mediaCache);
        },
        mouseOverEditButton: function (elem) {
            if (this.readOnly)
                return true;

            var $elem = $(elem);
            //ignore non disabled buttons
            if (!$elem.hasClass("propertymedia-btn-disabled"))
                return true;
            //create new message in popup.
            var $parent = $("span", $elem);
            this.createMessagePopup($parent, this.mediaCache);
            return true;
        },
        mouseOutEditButton: function (elem) {
            //remove popup, we always create new in mouseover on edit button.
            $(".propertymedia-message-popup", $(elem)).remove();
        },
        edit: function () {
            if (this.readOnly)
                return;

            var mediaReference = JSON.parse(this.getHiddenFieldValue());
            this.openEditor(this.mediaCache, mediaReference);
        },
        //callback for updating effects in selected media
        storeEffects: function (effects, callbackParams) {
            var self = this;

            // Add loader
            self.showLoader($("#" + self.thumbnailId));

            var mediaReference = JSON.parse(this.getHiddenFieldValue());
            mediaReference.Effects = effects;
            this.setHiddenFieldValue(JSON.stringify(mediaReference));
            $.event.trigger("/imagevault/propertymedia", this);

            this.getMedia(mediaReference, this.mediaCache.OriginalFormatContentType, this.propertyThumbnailWidth, this.propertyThumbnailHeight, this.propertyThumbnailResizeMode, function (mediaItem) {
                if (mediaItem) {

                    var $thumbnail = $("#" + self.thumbnailId);
                    var $thumbnailHiddenField = $("#" + self.thumbnailHiddenFieldId);

                    self.mediaCache.Thumb.Url = mediaItem.MediaConversions[0].Url;
                    self.mediaCache.Thumb.Height = mediaItem.MediaConversions[0].Height;
                    self.mediaCache.Thumb.Width = mediaItem.MediaConversions[0].Width;

                    $thumbnailHiddenField.val(JSON.stringify(self.mediaCache));

                    $thumbnail.attr("style", "visibility:hidden; width:" + self.mediaCache.Thumb.Width + "px; height:" + self.mediaCache.Thumb.Height + "px;");
                    $thumbnail.removeAttr("src");
                    $thumbnail.attr("src", self.mediaCache.Thumb.Url);

                    //ie don't remember the load event (or don't trigger it if a new image is set)
                    self.centerThumbnail($thumbnail, self.mediaCache);

                    self.UpdateUi();

                } else {
                    var err = "Error getting media from server. " + self.getClient().getLastErrorMessage();
                    alert(err);

                    // Hide loader
                    self.hideLoader($thumbnail);
                }
            });
        },
        //called when a user clicks the insert button in IVUI
        callback: function (data) {
            var self = this;
            var $thumbnailHiddenField = $("#" + this.thumbnailHiddenFieldId);
            //$hiddenField.focus();
            var mediaReference = { Id: data.Id };
            var mediaReferenceJson = JSON.stringify(mediaReference);
            this.setHiddenFieldValue(mediaReferenceJson);
            $thumbnailHiddenField.val("");
            var $thumbnail = $("#" + this.thumbnailId);
            this.createMediaCache(data, function (cache) {
                self.mediaCache = cache;
                self.mediaCache.VaultRole = 1; //Atleast view access when selected

                //create the cache (represents the MediaCacheItem)
                $thumbnailHiddenField.val(JSON.stringify(self.mediaCache));
                $thumbnail.attr("style", "visibility:hidden; width:" + self.mediaCache.Thumb.Width + "px; height:" + self.mediaCache.Thumb.Height + "px;");
                $thumbnail.removeAttr("src");
                $thumbnail.attr("src", self.mediaCache.Thumb.Url);
                //$hiddenField.blur();

                //ie don't remember the load event (or don't trigger it if a new image is set)
                self.centerThumbnail($thumbnail, self.mediaCache);

                self.UpdateUi();
                $.event.trigger("/imagevault/propertymedia", self);

            });
        },
        ClearSelection: function () {
            if (this.readOnly)
                return false;

            var self = this;
            var $removeLink = $("#" + this.removeLinkId);
            if ($removeLink.hasClass("propertymedia-btn-disabled")) {
                return false;
            }
            var doClear = confirm(this.clearConfirmMessage);
            if (doClear) {

                var $thumbnailHiddenField = $("#" + this.thumbnailHiddenFieldId);
                var $thumbnail = $("#" + this.thumbnailId);

                this.setHiddenFieldValue("");
                $thumbnailHiddenField.val("");

                $thumbnail.css("visibility", "hidden");
                $thumbnail.removeAttr("src");

                $thumbnail.attr("src", this.defaultIconUri);

                self.centerThumbnail($thumbnail);

                this.mediaCache = null;
                $thumbnail.css("visibility", "visible");

                this.UpdateUi();
            }

            return false;
        },
        //updates the ui for the control
        UpdateUi: function () {

            var mediaIsDeletedOrUserHasNoAccess = !this.mediaCache && $("#" + this.thumbnailId).attr("src") === "";

            var $thumbContainer = $("#" + this.thumbnailId).parent();
            var $thumbContainerInformation = $thumbContainer.find(".propertymedia-thumbnail-information");
            var $insertLink = $("#" + this.inserLinkId);
            if (!this.readOnly) {
                $insertLink.removeClass("propertymedia-btn-disabled");
            } else {
                $insertLink.addClass("propertymedia-btn-disabled");
            }

            var $removeLink = $thumbContainer.closest(".propertymedia-control").find("#" + this.removeLinkId);

            if ((this.mediaCache && this.mediaCache.OriginalFormatContentType && !this.readOnly) || mediaIsDeletedOrUserHasNoAccess) {
                $removeLink.removeClass("propertymedia-btn-disabled");
            } else {

                $removeLink.addClass("propertymedia-btn-disabled");
            }
            if (this.isEditable(this.mediaCache) && !this.readOnly) {
                this.$editLink.removeClass("propertymedia-btn-disabled");
            } else {
                this.$editLink.addClass("propertymedia-btn-disabled");
            }

            if (!this.readOnly) {
                $thumbContainer.removeClass("disabled");
            } else {
                $thumbContainer.addClass("disabled");
            }

            // Media is either removed or user has no access
            if (mediaIsDeletedOrUserHasNoAccess) {
                $thumbContainerInformation
                    .html("<span class=\"no-access-to-media-text\">Cannot find media in ImageVault. It\'s either removed or you don\'t have access.</span>");

                // Hide loader
                this.hideLoader($("#" + this.thumbnailId));

            } else {
                $thumbContainerInformation.html("");
            }

        }
    });
    ns.PropertyMedia = pm;
})(iv_jQuery, window.ImageVault != null ? window.ImageVault : window.ImageVault = {});
