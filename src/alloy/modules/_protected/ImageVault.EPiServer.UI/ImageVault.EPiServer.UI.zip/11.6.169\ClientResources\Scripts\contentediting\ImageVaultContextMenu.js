﻿define("imagevault/contentediting/ImageVaultContextMenu", [
// Dojo
"dojo/_base/declare",
"dojo/i18n",
"dojo/_base/lang",
"dojo/date/locale",
"dojo/string",
"dojo/html",
"dojox/html/entities",

// Dijit
"dijit",
"dijit/Menu",
"dijit/MenuItem",
"dijit/MenuSeparator",
"dijit/_WidgetsInTemplateMixin",

// EPi Framework
"epi",
"epi/shell/widget/_ModelBindingMixin",

// ImageVault Buttons
"imagevault/contentediting/ImageVaultButtons",

// Resources
"epi/i18n!epi/shell/ui/nls/imagevault.contextmenu"
],

function (
// Dojo
    declare,
    i18n,
    lang,
    locale,
    string,
    html,
    entities,

// Dijit
    dijit,
    Menu,
    MenuItem,
    MenuSeparator,
    _WidgetsInTemplateMixin,

// EPi Framework
    epi,
    _ModelBindingMixin,

// EPi CMS
   ImageVaultButtons,

// Resources
    res
    ) {

    return declare([Menu, _WidgetsInTemplateMixin, _ModelBindingMixin], {

        templateString: "<div data-dojo-type=\"dijit/Menu\" class=\"epi-blockContextMenu\">\r\n    <div data-dojo-type=\"dijit/MenuItem\" data-dojo-attach-point=\"removeMenuItem\" data-dojo-attach-event=\"onClick: _onRemove\" iconClass=\"epi-iconTrash\">${res.remove}</div>\r\n</div>",

        res: res,

        commands: null,

        model: null,

        onRemove: function () {
            // summary:
            //      Raise onRemove event on this editor
            // tag:
            //      Public callback
        },

        postMixInProperties: function () {
            this.inherited(arguments);

            //Bind the commands
            this.commands = this.commands || new ImageVaultButtons();

            this.commands.remove.watch("canExecute", lang.hitch(this, function () {
                if (this.removeMenuItem) {
                    this.removeMenuItem.set("disabled", !this.commands.remove.canExecute);
                }
            }));
        },

        postCreate: function () {
            this.inherited(arguments);
        },

        _setModelAttr: function (model) {
            // Update the model on the commands
            this.commands.set("model", model);
            this.inherited(arguments);
        },

        _onRemove: function () {
            this.commands.remove.execute();
            this.onRemove();
        },

    });
});
